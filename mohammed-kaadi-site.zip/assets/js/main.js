/* ============ إعدادات قابلة للتعديل ============ */
const CONFIG = {
  whatsapp: '963980351186',
  // ضع رابط Formspree هنا (مثال: https://formspree.io/f/xxxxxxx) لإرسال النموذج على الإيميل.
  // إذا تُرك فارغاً، يُرسل النموذج كرسالة واتساب جاهزة.
  formEndpoint: ''
};

(function () {
  const root = document.documentElement;
  root.classList.add('js');

  /* ----- الوضع الداكن ----- */
  const themeBtn = document.getElementById('themeToggle');
  const applyTheme = (t) => {
    root.setAttribute('data-theme', t);
    if (themeBtn) themeBtn.setAttribute('aria-pressed', String(t === 'dark'));
  };
  let saved = null;
  try { saved = localStorage.getItem('theme'); } catch (e) {}
  applyTheme(saved || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));
  if (themeBtn) {
    themeBtn.addEventListener('click', () => {
      const next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
      applyTheme(next);
      try { localStorage.setItem('theme', next); } catch (e) {}
    });
  }

  /* ----- قائمة الموبايل ----- */
  const navToggle = document.getElementById('navToggle');
  const navLinks = document.getElementById('navLinks');
  if (navToggle && navLinks) {
    navToggle.addEventListener('click', () => {
      const open = navLinks.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', String(open));
    });
    navLinks.querySelectorAll('a').forEach((a) => a.addEventListener('click', () => {
      navLinks.classList.remove('open');
      navToggle.setAttribute('aria-expanded', 'false');
    }));
  }

  /* ----- روابط واتساب برسالة جاهزة ----- */
  document.querySelectorAll('.whatsapp-btn').forEach((btn) => {
    const msg = btn.getAttribute('data-msg');
    if (msg) btn.setAttribute('href', 'https://wa.me/' + CONFIG.whatsapp + '?text=' + encodeURIComponent(msg));
  });

  /* ----- زر الأعلى ----- */
  const toTop = document.getElementById('toTop');
  if (toTop) {
    window.addEventListener('scroll', () => {
      toTop.classList.toggle('show', window.scrollY > 400);
    }, { passive: true });
    toTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
  }

  /* ----- ظهور تدريجي + عدادات ----- */
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const countUp = (el) => {
    const target = parseInt(el.dataset.count, 10);
    if (isNaN(target) || reduce) return;
    const prefix = el.dataset.prefix || '';
    const dur = 1200; const start = performance.now();
    const tick = (now) => {
      const p = Math.min((now - start) / dur, 1);
      el.textContent = prefix + Math.round(target * p);
      if (p < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  };
  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach((en) => {
        if (en.isIntersecting) {
          en.target.classList.add('in');
          en.target.querySelectorAll('[data-count]').forEach(countUp);
          io.unobserve(en.target);
        }
      });
    }, { threshold: 0.12 });
    document.querySelectorAll('.reveal').forEach((el) => io.observe(el));
  } else {
    document.querySelectorAll('.reveal').forEach((el) => el.classList.add('in'));
  }

  /* ----- تمييز القسم الحالي بالقائمة ----- */
  const links = document.querySelectorAll('#navLinks a[href^="#"]');
  if (links.length && 'IntersectionObserver' in window) {
    const map = new Map();
    links.forEach((a) => { const s = document.querySelector(a.getAttribute('href')); if (s) map.set(s, a); });
    const spy = new IntersectionObserver((entries) => {
      entries.forEach((en) => {
        if (en.isIntersecting) {
          links.forEach((l) => l.classList.remove('active'));
          const a = map.get(en.target); if (a) a.classList.add('active');
        }
      });
    }, { rootMargin: '-45% 0px -50% 0px' });
    map.forEach((_, s) => spy.observe(s));
  }

  /* ----- نموذج التواصل ----- */
  const form = document.getElementById('contactForm');
  if (form) {
    const status = document.getElementById('formStatus');
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (form.website && form.website.value) return; // honeypot
      const name = form.name.value.trim();
      const service = form.service.value;
      const msg = form.message.value.trim();
      if (!name || !msg) { status.textContent = 'عبّي الاسم والرسالة من فضلك.'; status.style.color = '#c0392b'; return; }
      status.style.color = '';
      if (CONFIG.formEndpoint) {
        try {
          const res = await fetch(CONFIG.formEndpoint, {
            method: 'POST', headers: { 'Accept': 'application/json' }, body: new FormData(form)
          });
          if (!res.ok) throw new Error();
          form.reset(); status.textContent = 'وصلتني رسالتك، رح أرد عليك بأقرب وقت ✔';
        } catch (err) { status.textContent = 'صار خطأ بالإرسال، جرّب واتساب.'; status.style.color = '#c0392b'; }
      } else {
        const text = 'مرحباً محمد، أنا ' + name + '\nالخدمة: ' + service + '\n' + msg;
        window.open('https://wa.me/' + CONFIG.whatsapp + '?text=' + encodeURIComponent(text), '_blank', 'noopener');
        status.textContent = 'تم تجهيز رسالتك على واتساب ✔';
      }
    });
  }

  /* ----- سنة الفوتر ----- */
  const y = document.getElementById('year');
  if (y) y.textContent = new Date().getFullYear();
})();
